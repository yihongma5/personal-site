#!/usr/bin/env python3
"""GitHub Claude Code Skills 星标追踪 + 相关度评分"""

import json
import os
import sys
import time
import urllib.request
import urllib.parse
import urllib.error
from datetime import datetime, timedelta
from pathlib import Path

CACHE_FILE = Path.home() / ".claude" / "ant-news-skills-cache.json"
MAX_REPOS = 80
MIN_STARS = 5

# 相关度关键词 + 权重 (排序: 个人提效 > 内容创作 > 跨境电商 > 新闻)
RELEVANCE_RULES = [
    (0.35, ["productivity", "workflow", "automation", "efficiency", "tool",
            "productiv", "efficien", "workflow", "automat", "shortcut",
            "personal", "daily", "routine", "task management", "habits"]),
    (0.30, ["content", "writing", "video", "creator", "media", "publish", "blog",
            "writer", "write", "article", "editor", "creative",
            "social media", "marketing", "post", "draft"]),
    (0.20, ["ecommerce", "trade", "shop", "commerce", "cross-border",
            "import", "export", "supply chain", "product", "retail",
            "dropshipp", "amazon", "aliexpress", "shopify"]),
    (0.15, ["news", "rss", "crawler", "scraping", "aggregator", "info",
            "crawl", "scrape", "feed", "aggregat", "headline",
            "digest", "curat", "monitor", "tracker"]),
]


def github_search(query: str, page: int = 1) -> dict:
    """搜索 GitHub 仓库"""
    params = urllib.parse.urlencode({
        "q": query,
        "sort": "stars",
        "order": "desc",
        "per_page": 30,
        "page": page,
    })
    url = f"https://api.github.com/search/repositories?{params}"
    req = urllib.request.Request(url, headers={
        "Accept": "application/vnd.github.v3+json",
        "User-Agent": "ant-news-daily-bot",
    })
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            return json.loads(resp.read().decode())
    except Exception as e:
        print(f"  ⚠ 搜索失败: {query[:40]}... {e}", file=sys.stderr)
        return {"items": []}


def collect_all_repos() -> list:
    """搜多组关键词，去重合并"""
    queries = [
        "claude code skill",
        "claude code plugin",
        "claude-skills",
        "claude plugin skill",
    ]
    seen = set()
    repos = []

    for q in queries:
        for page in (1, 2):
            data = github_search(q, page)
            for item in data.get("items", []):
                rid = item["full_name"]
                if rid not in seen:
                    seen.add(rid)
                    repos.append({
                        "full_name": rid,
                        "name": item["name"],
                        "description": (item.get("description") or ""),
                        "stars": item["stargazers_count"],
                        "url": item["html_url"],
                        "updated": item["updated_at"],
                        "pushed": item["pushed_at"],
                        "language": item.get("language") or "",
                        "topics": item.get("topics") or [],
                    })
            time.sleep(1.2)  # 限流
        if len(repos) >= MAX_REPOS:
            break

    # 去重按 star 降序
    repos.sort(key=lambda r: r["stars"], reverse=True)
    return repos[:MAX_REPOS]


def calc_relevance(repo: dict) -> float:
    """计算相关度得分 0-100"""
    text = (repo["description"] + " " + " ".join(repo["topics"]) + " " + repo["name"]).lower()
    score = 0.0
    for weight, keywords in RELEVANCE_RULES:
        hits = sum(1 for kw in keywords if kw.lower() in text)
        score += min(hits, 4) * weight * 25  # 每命中1个=25分，最多4个=满分
    return round(min(score, 100), 1)


def get_top_tags(repo: dict) -> list:
    """返回相关度最高的标签"""
    text = (repo["description"] + " " + " ".join(repo["topics"]) + " " + repo["name"]).lower()
    labels = {40: "内容创作", 60: "跨境电商", 20: "新闻聚合"}
    if any(kw in text for kw in ["productivity", "workflow", "automation", "efficiency", "tool"]):
        labels[80] = "个人提效"
    if any(kw in text for kw in ["content", "writing", "video", "creator", "media", "blog"]):
        labels[40] = "内容创作"
    if any(kw in text for kw in ["ecommerce", "trade", "shop", "commerce", "cross-border"]):
        labels[60] = "跨境电商"
    if any(kw in text for kw in ["news", "rss", "crawler", "scraping", "feed", "aggregator"]):
        labels[20] = "新闻聚合"
    # 返回得分最高的 2 个
    sorted_labels = sorted(labels.items(), key=lambda x: x[0], reverse=True)
    return [l[1] for l in sorted_labels[:2]]


def load_cache() -> dict:
    if CACHE_FILE.exists():
        with open(CACHE_FILE) as f:
            return json.load(f)
    return {}


def save_cache(data: dict):
    CACHE_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(CACHE_FILE, "w") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


def should_refresh(cache: dict) -> bool:
    """每周一刷新 (weekday=0)"""
    last = cache.get("last_refresh", "")
    if not last:
        return True
    last_date = datetime.fromisoformat(last)
    today = datetime.now()
    return today.weekday() == 0 and last_date.date() < today.date()


def run():
    now = datetime.now()
    today_str = now.strftime("%Y-%m-%d")
    monday = (now - timedelta(days=now.weekday())).strftime("%Y-%m-%d")
    cache = load_cache()

    # 判断是否需要刷新
    if not should_refresh(cache) and "star_growth" in cache:
        print(json.dumps(cache, ensure_ascii=False))
        print("", file=sys.stderr)
        print(f"  📦 使用缓存 (上次刷新: {cache['last_refresh']})")
        return

    print(f"  🔍 搜索 GitHub...", file=sys.stderr)
    repos = collect_all_repos()
    print(f"    获取到 {len(repos)} 个仓库", file=sys.stderr)

    # 计算周增量
    prev_stars = cache.get("star_snapshot", {})
    star_snapshot = {}
    for r in repos:
        name = r["full_name"]
        star_snapshot[name] = r["stars"]
        prev = prev_stars.get(name, r["stars"])
        r["star_growth"] = max(0, r["stars"] - prev)

    # 计算相关度
    for r in repos:
        r["relevance"] = calc_relevance(r)
        r["tags"] = get_top_tags(r)
        r["star_growth"] = r.get("star_growth", 0)

    # 两个榜单
    growth_top10 = sorted(repos, key=lambda r: r["star_growth"], reverse=True)[:10]
    relevance_top10 = sorted(repos, key=lambda r: (r["relevance"], r["stars"]), reverse=True)[:10]

    result = {
        "last_refresh": today_str,
        "week_start": monday,
        "star_snapshot": star_snapshot,
        "star_growth": growth_top10,
        "relevant": relevance_top10,
        "total_scanned": len(repos),
    }

    # 清理 growth/relevant 只保留展示字段
    keep_fields = ["full_name", "name", "description", "stars", "star_growth", "url", "relevance", "tags", "language"]
    result["star_growth"] = [{k: r[k] for k in keep_fields if k in r} for r in growth_top10]
    result["relevant"] = [{k: r[k] for k in keep_fields if k in r} for r in relevance_top10]

    save_cache(result)
    print(json.dumps(result, ensure_ascii=False))
    print(f"  ✅ 已更新缓存 ({today_str})", file=sys.stderr)
    print(f"     🔥 星标飙升: {len(growth_top10)} 个", file=sys.stderr)
    print(f"     🎯 与你相关: {len(relevance_top10)} 个", file=sys.stderr)


if __name__ == "__main__":
    run()
