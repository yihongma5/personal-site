# 新闻源权威清单

## 科技类

| 媒体 | 网址 | 特点 | 搜索语法 |
|------|------|------|----------|
| TechCrunch | techcrunch.com | 创投、科技公司动态 | `site:techcrunch.com <keyword>` |
| The Verge | theverge.com | 消费电子、互联网文化 | `site:theverge.com <keyword>` |
| Hacker News | news.ycombinator.com | 工程师社区精选 | `site:news.ycombinator.com` |
| Wired | wired.com | 科技与社会交叉话题 | `site:wired.com <keyword>` |
| Ars Technica | arstechnica.com | 硬核技术深度报道 | `site:arstechnica.com <keyword>` |

## 国际类

| 媒体 | 网址 | 特点 | 搜索语法 |
|------|------|------|----------|
| 路透社 | reuters.com | 全球财经政治 | `site:reuters.com <keyword>` |
| 美联社 | apnews.com | 全球新闻通讯 | `site:apnews.com <keyword>` |
| 环球时报 | globaltimes.cn | 中国视角国际新闻 | `site:globaltimes.cn` |
| BBC News | bbc.com/news | 英国公共广播 | `site:bbc.com/news <keyword>` |
| NHK World | www3.nhk.or.jp/nhkworld | 亚洲视角国际新闻 | `site:nhk.or.jp/nhkworld` |

## 外贸类

| 媒体 | 网址 | 特点 | 搜索语法 |
|------|------|------|----------|
| 中华人民共和国商务部 | mofcom.gov.cn | 外贸政策权威发布 | `site:mofcom.gov.cn` |
| 世界贸易组织 | wto.org | 全球贸易规则动态 | `site:wto.org` |
| 国际贸易中心 | intracen.org | 贸易数据与分析 | `site:intracen.org` |
| 中国海关总署 | customs.gov.cn | 进出口数据、政策 | `site:customs.gov.cn` |
| 第一财经 | yicai.com | 贸易/经济深度报道 | `site:yicai.com 外贸` |

## 搜索策略

- 科技：英文搜索为主，结果翻译成中文摘要
- 国际：中英文混合搜索，覆盖不同立场信源
- 外贸：中英文混合搜索，优先中国商务部和 WTO 一手信息
- 每次搜索加 `after:7 days ago` 或类似机制过滤 24h 内容
- 对重要新闻用 WebFetch 获取原文核实细节
