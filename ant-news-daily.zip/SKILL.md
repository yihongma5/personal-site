---
name: ant-news-daily
description: 每日新闻聚合工具，精选科技、国际、外贸三大领域的24小时热门资讯并以可视化HTML页面展示。触发词："今日新闻"、"蚂蚁日报"、"每日新闻"、"最新新闻"、"今天有什么新闻"、"新闻早报"、"行业动态"。当用户想看新闻、了解今日热点、获取行业资讯时使用。
---

# 蚂蚁日报 / Ant News Daily

每日精选科技、国际、外贸三大行业资讯，生成可视化中文摘要日报。

## 工作流程

分三步并行执行：

### 第一步：并行抓取三大领域新闻（用 WebSearch，每条搜索限最新24h）

**科技**（执行以下搜索，各返回前5条）：
- `site:techcrunch.com 最新科技新闻 2026`
- `site:theverge.com latest tech news 2026`
- `site:news.ycombinator.com top stories`
- `科技行业最新动态 重大新闻 2026年5月`

**国际**（执行以下搜索，各返回前5条）：
- `site:reuters.com latest world news`
- `site:apnews.com top headlines`
- `site:globaltimes.cn 国际新闻 最新`
- `国际重大新闻 今日热点 2026年5月`

**外贸**（执行以下搜索，各返回前5条）：
- `site:mofcom.gov.cn 商务部 最新政策 外贸`
- `site:wto.org latest trade news`
- `外贸进出口 最新政策 国际贸易动态 2026年5月`

所有搜索并行发起，不等结果。

### 第二步：筛选和摘要生成

搜索结果汇总后：

1. **去重去噪**：过滤掉无实质内容的链接、重复报道、非24小时内的旧闻
2. **精选**：每领域保留 **5-8 条**最有价值的资讯，确保覆盖面和深度
3. **摘要**：每条资讯用中文写 50-100 字摘要，包含：
   - 核心事件是什么
   - 为什么值得关注（行业影响/商业价值）
4. **按热度排序**：每条资讯根据以下信号综合评估热度，热度高的排前面：
   - 搜索结果中的排名/收录位置
   - 是否被多家媒体交叉报道（同一事件被 ≥2 个来源提及 → 热度加权）
   - 是否为行业龙头/核心事件（Google、英伟达、中美对话等 → 热度加权）
   - HN 等社区平台直接有点评分数作为热度参考
   - 评估原则：事件本身的影响力 > 媒体标题党程度
5. **标签**：每条标注 1-3 个关键词标签，用于快速定位
6. **出处**：标注来源媒体和发布日期，附可点击原文 URL

### 第三步：生成并打开 HTML 日报

使用 `assets/template.html` 模板生成最终页面。

**单条卡片 HTML 格式（必须严格遵循）：**

卡片必须是 `<div>`（不是 `<a>`），以支持文字选中复制。外链放在 `↗` 图标上。

```html
<div class="card">
  <div class="card-header">
    <h3>新闻标题（中文翻译）</h3>
    <a class="ext-link" href="原文URL" target="_blank" rel="noopener" title="查看原文">↗</a>
  </div>
  <p>50-100字中文摘要，客观陈述核心事实和为什么值得关注。</p>
  <div class="meta">
    <div class="tags">
      <span class="tag">#关键词1</span>
      <span class="tag">#关键词2</span>
    </div>
    <span class="source"><span class="heat heat-3"><span class="heat-dot on"></span><span class="heat-dot on"></span><span class="heat-dot on"></span></span> 路透社 · 3小时前</span>
  </div>
  <div class="insight">
    <span class="insight-label">💡 启发</span>
    <span class="insight-text">该项技术突破意味着XX领域的进入门槛正在降低。</span>
  </div>
</div>
```

- 无准确外链时不放 `<a class="ext-link">`，`↗` 图标省略

**启发模块规则：**
- 每条新闻评估是否值得写启发，没有则省略整个 `.insight` 块
- 启发角度：对个人的启示、行业趋势映射、隐藏信号、可行动建议、风险警示
- 保持客观，不强行升华，30-70字
- 禁止空洞套话（"值得关注"、"引发思考"这类说了等于没说的跳过）

热度指示器颜色规则：
- `heat-3`（3颗点亮）= 红色 `#ef4444`，顶级热度（龙头事件/多源交叉验证/权威发布）
- `heat-2`（2颗点亮）= 橙色 `#f59e0b`，中等热度（重要行业动态/多方关注）
- `heat-1`（1颗点亮）= 青色 `#06b6d4`，一般热度（值得关注但影响力有限）
- 未点亮的圆点始终灰色 `#e5e5e5`

**生成步骤：**

1. 读取 `assets/template.html` 模板
2. 为每条精选资讯生成上述卡片 HTML
3. 替换模板占位符：
   - `{{DATE}}` → 当天日期 YYYY年MM月DD日
   - `{{DATE_ISO}}` → ISO 日期 YYYY-MM-DD
   - `{{TECH_NEWS}}` / `{{WORLD_NEWS}}` / `{{TRADE_NEWS}}` → 各领域卡片
   - `{{TOTAL_COUNT}}` → 资讯总条数
   - 每个 section-title 旁的 `X 条` 替换为实际条数
4. 确保目录存在：`mkdir -p ~/Documents/蚂蚁日报`
5. 写入 `~/Documents/蚂蚁日报/ant-news-{{DATE_ISO}}.html`
6. 执行 `open ~/Documents/蚂蚁日报/ant-news-{{DATE_ISO}}.html` 在浏览器打开

### 第四步：GitHub Skills 周报

每周一刷新数据，其他天读缓存。

1. 运行 `python3 scripts/skills_tracker.py` 获取 JSON 结果
2. `star_growth` 数组 = 🔥 星标飙升 TOP 10，`relevant` 数组 = 🎯 与你相关 TOP 10
3. 在 HTML 中生成深色主题板块（与前三板块视觉区隔，用 `.section.skills` 类名）
4. 每条格式（必须包含 `data-repo` 属性和 `.fav-btn` 收藏按钮，放在 star 旁边）：

```html
<a class="card-dark" href="仓库URL" target="_blank" rel="noopener" data-repo="owner/repo">
  <div class="card-header">
    <h3>owner/repo</h3>
    <span class="ext">↗</span>
  </div>
  <p>仓库描述（原文英文即可，不翻译）</p>
  <div class="skill-summary">📌 中文总结：一句话说清这个 skill 做什么</div>
  <div class="skill-suggest">💡 建议：适用场景 / 可替换现有工具 / 值得安装的理由（没有则省略此条）</div>
  <div class="meta">
    <div class="tags">
      <span class="tag-dark">相关维度标签1</span>
      <span class="tag-dark">相关维度标签2</span>
    </div>
    <span class="source-dark">⭐ {stars} <span class="growth">+{growth}本周</span> <button class="fav-btn" data-repo="owner/repo" onclick="event.preventDefault();event.stopPropagation();var f=JSON.parse(localStorage.getItem('ant-news-skills-fav')||'[]');var i=f.indexOf(this.getAttribute('data-repo'));i>=0?f.splice(i,1):f.push(this.getAttribute('data-repo'));localStorage.setItem('ant-news-skills-fav',JSON.stringify(f));var c=document.getElementById('favCount');if(c)c.textContent=f.length;this.textContent=f.indexOf(this.getAttribute('data-repo'))>=0?'★ 已收藏':'☆ 收藏';this.className='fav-btn'+(f.indexOf(this.getAttribute('data-repo'))>=0?' faved':'')">☆ 收藏</button></span>
  </div>
</a>
```

5. 每条 skill 必须补充中文总结（.skill-summary），有实际价值时再写建议（.skill-suggest），不强凑
6. 建议角度：这个 skill 适合你日常哪个场景（内容创作/跨境电商/信息聚合/个人提效）、能否替代现有工具、是否比你现在用的方案更好

## 摘要质量标准

每条摘要卡片需包含：
- 标题（原文标题的准确中文翻译）
- 摘要正文（50-100 字，客观陈述，不添加观点）
- 标签（如：#AI #半导体 #地缘政治 #关税 #供应链）
- 来源 + 时间（如：路透社 · 3小时前）

## 过滤标准

**保留**：行业重大事件、政策变化、技术突破、市场动态、重大交易/投资
**丢弃**：八卦/娱乐、纯广告/软文、与三大领域无关、24小时前的旧闻

## 外链规则

**仅当搜索结果的 URL 明确是该条新闻的专项报道时才加 href。** WebSearch 返回的聚合摘要页面（一篇页面覆盖多个话题）不能作为单条新闻的外链。无法确认准确链接时，card 不加 href，去掉 `↗` 图标，样式改为 `cursor:default`。

## 输出格式

```
## 🐜 蚂蚁日报 | YYYY年MM月DD日

> 今日共精选 XX 条行业资讯 · 已打开可视化日报页面

| 领域 | 条数 | 头条 |
|------|------|------|
| 🔬 科技 | X | 标题摘要 |
| 🌍 国际 | X | 标题摘要 |
| 📦 外贸 | X | 标题摘要 |

📄 完整日报：/tmp/ant-news-YYYY-MM-DD.html（已在浏览器打开）
```

## 附：新闻源权威列表

详见 `references/sources.md`，包含科技/国际/外贸领域的权威媒体完整清单和搜索策略。
